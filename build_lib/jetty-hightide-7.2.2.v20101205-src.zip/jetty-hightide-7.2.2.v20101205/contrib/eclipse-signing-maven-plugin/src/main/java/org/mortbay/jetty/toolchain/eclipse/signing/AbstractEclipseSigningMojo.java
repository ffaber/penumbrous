package org.mortbay.jetty.toolchain.eclipse.signing;

import java.io.File;
import java.net.InetAddress;

import org.apache.maven.artifact.manager.WagonManager;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.settings.Settings;
import org.apache.maven.wagon.CommandExecutor;
import org.apache.maven.wagon.Wagon;
import org.codehaus.mojo.wagon.shared.WagonUtils;

public abstract class AbstractEclipseSigningMojo extends AbstractMojo
{
    /**
     * @component
     */
    protected WagonManager wagonManager;

    /**
     * The current user system settings for use in Maven.
     * 
     * @parameter expression="${settings}"
     * @readonly
     */
    protected Settings settings;

    /**
     * protocol for the wagon connection
     * 
     * Example: scp://
     * 
     * @parameter
     */
    protected String wagonProtocol;

    /**
     * host portion of the wagon connection
     * 
     * Example: build.eclipse.org
     * 
     * @parameter
     */
    protected String wagonHost;

    /**
     * path portion of the wagon connection
     * 
     * Example: /home/data/users/jmcconnell
     * 
     * @parameter
     */
    protected String wagonPath;

    /**
     * @parameter
     */
    protected String serverId;

    /**
     * @parameter default-value="900000";
     * @required
     */
    protected int wagonTimeout;

    /**
     * 
     * @return
     * @throws Exception
     */
    protected boolean runningOnBuildMachine() throws Exception
    {
        if (InetAddress.getLocalHost().getHostName().equals("build.eclipse.org"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    protected String adjustToWagonPath(String location)
    {
        return wagonPath + File.separator + location;
    }

    protected String getWagonUrl() throws Exception
    {
        if (wagonProtocol == null || wagonHost == null || wagonPath == null)
        {
            throw new IllegalArgumentException("missing wagon configuration bits, unable to operate remotely");
        }

        if (runningOnBuildMachine() )
        {
            return wagonProtocol + wagonPath;
        }
        
        return wagonProtocol + wagonHost + wagonPath;
    }

    protected Wagon createWagon(String id, String url) throws MojoExecutionException
    {
        try
        {
            return WagonUtils.createWagon(id,url,wagonManager,settings,this.getLog());
        }
        catch (Exception e)
        {
            throw new MojoExecutionException("Unable to create a Wagon instance for " + url,e);
        }

    }

    protected CommandExecutor getCommandExecutor(Wagon wagon) throws Exception
    {
        if (!(wagon instanceof CommandExecutor))
        {
            throw new MojoExecutionException("unable to operate remotely, requires wagon capable of involking commands");
        }

        CommandExecutor exec = (CommandExecutor)wagon;

        exec.setTimeout(wagonTimeout);

        return exec;
    }
}
