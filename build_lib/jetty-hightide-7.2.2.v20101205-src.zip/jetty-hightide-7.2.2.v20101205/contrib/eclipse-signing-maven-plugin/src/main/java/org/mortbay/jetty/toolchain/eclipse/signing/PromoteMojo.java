package org.mortbay.jetty.toolchain.eclipse.signing;

//========================================================================
//Copyright (c) 2010 Intalio, Inc.
//------------------------------------------------------------------------
//All rights reserved. This program and the accompanying materials
//are made available under the terms of the Eclipse Public License v1.0
//and Apache License v2.0 which accompanies this distribution.
//The Eclipse Public License is available at 
//http://www.eclipse.org/legal/epl-v10.html
//The Apache License v2.0 is available at
//http://www.opensource.org/licenses/apache2.0.php
//You may elect to redistribute this code under either of these licenses. 
//========================================================================

import java.io.File;
import java.io.IOException;
import java.util.zip.ZipFile;

import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.wagon.CommandExecutor;
import org.apache.maven.wagon.Wagon;
import org.codehaus.plexus.util.FileUtils;

/**
 * 
 * @goal promote
 * @phase package
 * @description runs the eclipse packing process
 */
public class PromoteMojo extends AbstractEclipseSigningMojo
{ 
    /**
     * zip file to get signed
     * @parameter
     * @required
     */
    protected String inputFile;
 
    /**
     * directory to promote artifact to
     * @parameter
     * @required
     */
    protected String promotionDirectory;
    
    /**
     * unpack path for artifact
     * @parameter default-value="${project.artifactId}-${project.version}"
     * @required
     */
    protected String unpackPath;
    
    /**
     * version
     * @parameter default-value="${project.version}"
     * @required
     */
    protected String version;
    
    public void execute() throws MojoExecutionException, MojoFailureException 
    {       	
        try
        {         	        	         
                promoteRemotely();           
        }
        catch (Exception e)
        {
            getLog().error(e);
        }
    }
 
    private void promoteRemotely() throws Exception
    {
        File input = new File(inputFile);
        //read the zip file to see the top level directory:
        String topLevelDirectory = "/repository";
        ZipFile zInput = null;
        try
        {
                zInput = new ZipFile(input);
                if (zInput.getEntry("site") != null)
                {
                        topLevelDirectory = "/site";
                }
                else if (zInput.getEntry("repository") != null)
                {
                        topLevelDirectory = "/repository";
                }
                else if (zInput.getEntry("plugins") != null)
                {
                        topLevelDirectory = "";
                }
        }
        catch (Throwable t)
        {
                //nevermind, repository is the default and will do fine.
        }
        finally
        {
                if (zInput != null) try { zInput.close(); } catch (IOException ioe) {}
        }
        
        Wagon wagon = createWagon(serverId,getWagonUrl());

        CommandExecutor exec = getCommandExecutor(wagon);

        info("creating remote directory");    
        exec.executeCommand("/bin/mkdir -p " + adjustToWagonPath(promotionDirectory) + "/tmp");
        
        info("setting permissions on directory" );
        exec.executeCommand("/bin/chmod -R ugo+rw " + adjustToWagonPath(promotionDirectory));
        
        info("putting promotion file into position");
        wagon.put(new File(inputFile), promotionDirectory + "/tmp");
        
        info("unzipping promotion file");
        exec.executeCommand("/usr/bin/unzip " + adjustToWagonPath(promotionDirectory) + "/tmp/" + FileUtils.basename(inputFile,".zip") + " -d " + adjustToWagonPath(promotionDirectory) + "/tmp");
        
        info("moving promoted directory into place");
        exec.executeCommand("/bin/mv " + adjustToWagonPath(promotionDirectory) + "/tmp/" + FileUtils.basename(inputFile, ".zip")  + "/site/* " + adjustToWagonPath(promotionDirectory) );
  
        info("cleaning up");
        exec.executeCommand("/bin/rm -Rf " + adjustToWagonPath(promotionDirectory) + "/tmp");
    }
    
    private void cleanup()
    {
    	getLog().info("cleaning up after unzip");
    	//FileUtils.removePath(promotionDirectory + File.separator + FileUtils.basename(packedZipFile,".zip"));
    	//FileUtils.remotePath()
    }
    
    private void info(String log)
    {
        getLog().info("[PROMOTE] " + log);
    }

    
}
