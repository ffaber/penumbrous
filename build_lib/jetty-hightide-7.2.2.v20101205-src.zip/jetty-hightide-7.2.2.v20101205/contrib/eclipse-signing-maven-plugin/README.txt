Below is a snapshot of the profile that we use with jetty.

> mvn -PpackAndSite clean install

The example below shows both styles of running pack200, the remote version
takes quite a while to execute because the build.eclipse.org machine is 
rather slow and the pack200 default setting is based on an ibm jdk on that 
machine.  Care should be taken to pack with the same version of java
that your artifacts are planning on releasing with.

To execute the sign on build.eclipse.org (which it has to be) you need to 
mail the webmaster@eclipse.org and have your username added as an executor
of the /usr/bin/sign script.  

You should use a setting.xml somewhat like this:

     <server>
      <id>project.eclipse.website</id>
      <username>foo</username>
      <privateKey>/home/bar/.ssh/priv</privateKey>
      <passphrase/>
    </server>


-------------------------------------------------------------------------


	<profiles>
		<profile>
			<id>packAndSign</id>
			<build>
				<plugins>
					<plugin>
						<groupId>org.mortbay.jetty.toolchain</groupId>
						<artifactId>eclipse-signing-maven-plugin</artifactId>
						<version>1.0-SNAPSHOT</version>
						<executions>
						<!--  example of executing locally for pack -->
							<execution>
								<id>pack</id>
								<configuration>
									<execute>local</execute>
									<pack200>/usr/lib/jvm/java-6-sun/bin</pack200>
								</configuration>
								<phase>package</phase>
								<goals>
									<goal>pack</goal>
								</goals>
							</execution>
						<!-- the sign remote -->
							<execution>
								<id>sign</id>
								<configuration>
									<wagonProtocol>scpexe://</wagonProtocol>
									<wagonHost>build.eclipse.org</wagonHost>
									<wagonPath>/home/data/httpd/download-staging.priv/rt/jetty
									</wagonPath>
									<serverId>jetty.eclipse.website</serverId>
									<inputFile>${project.build.directory}/packed/${project.artifactId}-${project.version}.zip
									</inputFile>
								</configuration>
								<phase>package</phase>
								<goals>
									<goal>sign</goal>
								</goals>
							</execution>
						<!-- example of remote pack -->
							<execution>
								<id>repack</id>
								<configuration>
								    <execute>remote</execute>
									<wagonProtocol>scpexe://</wagonProtocol>
									<wagonHost>build.eclipse.org</wagonHost>
									<wagonPath>/home/data/users/jmcconnell</wagonPath>
									<serverId>jetty.eclipse.website</serverId>
									<inputFile>${project.build.directory}/signed/${project.artifactId}-${project.version}.zip
									</inputFile>
								</configuration>
								<phase>package</phase>
								<goals>
									<goal>pack</goal>
								</goals>
							</execution>
						<!-- signing and pack alters tycho checksums so fix them -->
							<execution>
								<id>fixCheckSums</id>
								<configuration>
									<inputFile>${project.build.directory}/packed/${project.artifactId}-${project.version}.zip
									</inputFile>
									<outputFile>${project.build.directory}/fixed/${project.artifactId}-${project.version}.zip</outputFile>
									<artifactsXml>${project.build.directory}/checksumFix/${project.artifactId}-${project.version}/site/artifacts.xml
									</artifactsXml>
								</configuration>
								<phase>package</phase>
								<goals>
									<goal>fixCheckSums</goal>
								</goals>
							</execution>
						<!-- promote the release somewhere -->
							<execution>
								<id>promoteSite</id>
								<configuration>
									<wagonProtocol>scpexe://</wagonProtocol>
									<wagonHost>build.eclipse.org</wagonHost>
									<wagonPath>/home/www/jetty/nightly</wagonPath>
									<serverId>jetty.eclipse.website</serverId>
									<inputFile>${project.build.directory}/fixed/${project.artifactId}-${project.version}.zip</inputFile>
									<promotionDirectory>I${project.version}</promotionDirectory>
								</configuration>
								<phase>package</phase>
								<goals>
									<goal>promote</goal>
								</goals>
							</execution>
						</executions>
					</plugin>
				</plugins>
			</build>
		</profile>
	</profiles>