/**
 * Dynamic Finder API for Guice Persist.
 */
package com.google.inject.persist.finder;